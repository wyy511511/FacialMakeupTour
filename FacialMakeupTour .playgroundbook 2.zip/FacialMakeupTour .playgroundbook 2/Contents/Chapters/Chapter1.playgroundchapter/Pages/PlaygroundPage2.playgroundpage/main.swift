/*:
 In western opera, role division is based on the sex and voice of the singer,
 but in Chinese opera it is made according to the sex and personality of
 the dramatic character. The various roles are roughly classified into four
 types: Males with unpainted faces (sheng), females (tan), males with
 heavily painted faces (jing), and chou (clowns). For centuries, only men
 or boys could act in opera, including the female roles. Today, women in
 most cases play female roles, and they often take men's roles as well.
 The four roles are subdivided, based on the characters' age, tempera-
 ment, and the kind of singing, speech, gesticulation, and martial displays
 they are called upon to make.
 ![shengtanjingchouminiimage](sdjcmini2)
 
 ## Sheng(Males with unpainted faces)
 ### Lao-sheng
 A male, over thirty years old, who sings and speaks in a low and deep
 natural voice and who has a long beard, black or white according to
 his age.
 ### Wu-sheng
 A martial arts young man who sings and speaks in his natural voice
 and specializes in kung fu and acrobatics.
 ### Hsiao-sheng
 A handsome and suave young man who speaks in a voice
 compounded of the natural and the artificial. He sings in a
 high-pitched falsetto.
 

 ## Tan(Females)
 ### Ching-yi
 A rather formal female, chaste and respectable, whose role calls for
 top-quality singing, enunciation and exquisite gesticulation. She
 always uses the falsetto.
 
 ### Hua-tan
 A young, frolicsome, and often roguish girl full of vivacity and
 innocence. Her acting stresses these qualities, and she sings and
 speaks in a falsetto.
 ### Wu-tan
 The female counterpart of the wu-sheng, she is both beautiful and
 well-versed in the martial arts. She also sings and speaks in a falsetto.
 ### Lao-tan
 An old woman who sings and speaks in her natural voice, but on a
 higher pitch than does her male counterpart, the lao-sheng.
 
 
 ## Jing(Males with heavily painted faces)
 - The facial makeup of a jing character is complicated and rich in
 form.
 - These characters sing and speak in a deep-throated natural voice,
 although somewhat on the nasal side. Their makeup is particularly
 striking, with varicolored painted faces indicating their character.
 - In Chinese opera, there are many schools of facial makeup for a Jing
 character, each with a style of its own.
 
 

 The facial makeup for the Jing character is constantly developing from
 plain to three-dimensional, from simple to complicated. Actors have in
 their long-term practice on stage absorbed what is good in other schools,
 and are constantly exploring new skills in their application of color
 and patterns to the facial makeup of most characters. As a result,
 certain rules have been formed, and models in the use of color and
 patterns have been created.
 ![jing](jing)
 
 ## Chou(Clowns)
 Clowns can be male or female (tsai-tan). They are sly or stupid,
 sometimes mean, but invariably ridiculous and laughter-provoking.
 They sing in a natural voice, but whether they are singing or acting,
 a hint of exaggeration is always present. The male is marked by a patch
 of white paint around the eyes and on the nose.
 

 
 
 [Next Page](@next)
 
 */


//#-hidden-code
///Liu, Hsueh-Fang, "The Art of facial makeup in Chinese opera" (1997). Thesis. Rochester Institute of Technology.
//#-end-hidden-code

