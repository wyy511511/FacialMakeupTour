import SwiftUI
import PlaygroundSupport
struct ContentView : View{
    var body: some View{

        Image("minicolor")
            

    }
}

PlaygroundPage.current.setLiveView(ContentView())


