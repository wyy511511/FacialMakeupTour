/*:
 # Every Face Tell a Story
 It is in the Ching category, Painted Faces, that facial paintings are most
 fascinating and significant, for each type of face symbolizes the personality of the character, By looking at the painted face, the audience
 immediately knows what kind of a person the role impersonates. A red
 face suggests loyalty, such as Kuan Kung, and a white face, a treacherous person, such as Ts'ao Ts'ao. A black face suggests an upright and
 just person such as Pao Kung, a prime minister during the Sung Dynasty
 who, according to legends, could descend to the underworld and by
 negotiating with Hades give back life to those who had died innocently
 through betrayal or other causes. A face painted in black and white
 denotes a courageous careless person. Green, purple, or reddish faces
 are either bandits or evil spirits. Golden faces represent gods or super-
 natural beings.
 
 # Symbolic Meaning of Colors 🟨🟦🟩🟥⬛️⬜️
 Facial makeup is rich in colors. In bright colors and with consummate
 skills, the artist creates various exquisite and true-to-life facial makeup
 patterns by delicately painting the forehead, the brows, the nose and
 other parts of the face. Every facial makeup is composed of three different colors or more, each symbolic of a certain aspect of the character's
 temperament, so that the characters in a play can be represented by different images symbolically and in an exaggerated manner. Some examples can illustrate this point.
 
 
 ![color](color)

 [Next Page](@next)
 */
