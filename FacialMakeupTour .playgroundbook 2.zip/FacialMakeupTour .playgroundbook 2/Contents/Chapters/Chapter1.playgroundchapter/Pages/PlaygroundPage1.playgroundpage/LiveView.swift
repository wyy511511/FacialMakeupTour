import SwiftUI
import PlaygroundSupport
struct ContentView : View{
    var body: some View{

        Image("opera")
            .resizable()

    }
}

PlaygroundPage.current.setLiveView(ContentView())

