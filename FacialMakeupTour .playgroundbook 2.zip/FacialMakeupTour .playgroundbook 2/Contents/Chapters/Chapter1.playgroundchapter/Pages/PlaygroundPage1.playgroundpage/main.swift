/*:
 Facial makeup, a special art in Chinese operas, distinctly shows the
 image of certain roles by means of artistic exaggeration combining
 truthful portrayal and symbolism. The appearance of a role reveals disposition and moral quality, age and distinguishing features. Actors and
 actresses in folk operas through the centuries, basing themselves on history and novels, legends and folk tales, and departing from their simple
 materialist viewpoint, have created numerous types of facial makeup for
 theatrical figures, to express their praise or condemnation, their sympathy and sentimental attachment, so that the audience would immediately know whom to love and whom to hate even though they might not
 make any comments in words.
 
 
 
## **Tips:**
 **Run code to put it on your face！** 😊😊😊



 In the later chapters you can choose your favorite facial makeup and background music, and you can also experience your own design！
 
 
 
 
[Next Page](@next)

*/

 
//#-hidden-code
import UIKit
import BookCore
import PlaygroundSupport

// Instantiate a new instance of the live view from BookCore and pass it to PlaygroundSupport.
//[Adding Files](Chapters/Chapter3.playgroundchapter/Pages/PlaygroundPage.playgroundpage/heihei\20%Files.swift )
testimage = #imageLiteral(resourceName: "face1")
PlaygroundPage.current.liveView = instantiateLiveView()

//#-end-hidden-code





