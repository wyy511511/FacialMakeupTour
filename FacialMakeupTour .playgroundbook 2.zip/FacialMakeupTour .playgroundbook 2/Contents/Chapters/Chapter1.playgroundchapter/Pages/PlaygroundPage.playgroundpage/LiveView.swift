//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Instantiates a live view and passes it to the PlaygroundSupport framework.
//

import UIKit
import BookCore
import PlaygroundSupport

testimage = #imageLiteral(resourceName: "07")


PlaygroundPage.current.liveView = instantiateLiveView()
//#-end-hidden-code



//
//import SwiftUI
//import PlaygroundSupport
//struct ContentView : View{
//    var body: some View{
//        Image("homepage")
//            .resizable()
//
//
//
//    }
//}
//
//PlaygroundPage.current.setLiveView(ContentView())
//Classic facial makeup image assessed from https://www.lanrentuku.com .Because it's difficult for me to design many amazing pictures of facial makeup.
