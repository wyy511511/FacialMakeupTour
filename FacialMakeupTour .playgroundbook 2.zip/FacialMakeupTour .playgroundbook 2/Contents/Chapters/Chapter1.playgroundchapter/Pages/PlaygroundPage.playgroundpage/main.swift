/*:
 Facial makeup, a special art in Chinese operas, which distinctly shows the image of certain roles by means of artistic exaggeration combining truthful portrayal and symbolism.
 
 \
 In this tour, you will learn about facial makeup and experience the combination of technology and traditional artwork.
 
 ### Later, you can use your Apple Pencil to design your own artwork and experience it with AR！😉😉
 
 
[Move on](@next) and have fun!
 
 ![homepage](homepage)
*/
