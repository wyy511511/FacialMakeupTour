/*:
 In Chinese opera, there is a large variety of facial makeup patterns .
 "whole face", "quartered face", "three tile face", "six-division face",
 "tiny flowered face", "lopsided face", etc. With vivid imagination and
 exaggeration, artists give prominence to the creation of the complicated
 characters in a play by painting their faces in a variety of colors such as
 red, orange, blue, white, black, purple, green, gold and silver. The large
 number of facial makeups reveal in form as well as in spirit and sense
 the character's loyalty or treachery, kindness or evil. The facial makeup
 patterns, finely painted, beautifully designed and exquisite in their variation of colors,
 are both highly artistic and iluminating. It is a national art appreciated and loved by the Chinese people.
 
 - ## Lopsided
 A lopsided pattern is one in which the two sides of the face are not
 arranged symmetrically. Characters who display this face pattern are
 flawed in some manner.
 
 - ## Fractured
 This pattern appears on the faces of generals of lower standing and
 wandering warriors. It originally consisted of a three-tile pattern with
 the addition of a few extra patterns and colors. Over time, it became so
 complicated that it ceased to resemble a three-tile pattern.
 
 - ## Numeral Ten
 The most distinctive component of this pattern is cross-shaped pattern
 centered on the bridge of the nose formed by two bisecting lines of
 paint, one of which runs from under the nose up to the top of the forehead, and the other which runs across the eyes. The cross-shape is reminiscent of the written Chinese character for the numeral ten.
 
 - ## Three-tile
 This is the most commonly occurring facial pattern. It consists of one
 color applied to the forehead, nose and cheeks, along with varying patterns and colors used to emphasize the eyebrows, eyes and mouth
 regions.
 
 - ## Variegated
 Like the fractured pattern, a variegated pattern was derived from the
 three-tile style of face-painting. The important difference between a
 fractured face and variegated face lies in their color arrangement. If the
 forehead and cheeks display one primary color, then the pattern is fractured. If the colors of the forehead and cheeks differ, than the pattern is
 variegated.
 
 - ## Solid
 A solid pattern is one that, with the exception of the eyebrows, is painted in one primary color. Characters with a solid face pattern are
 paragons of virtue.
 
 - ## Numeral Six
 This pattern resembles the written Chinese character for the numeral
 six. Elderly, respectable government ministers or generals commonly
 feature a numeral six pattern.
 
 [Next Page](@next)
 */
