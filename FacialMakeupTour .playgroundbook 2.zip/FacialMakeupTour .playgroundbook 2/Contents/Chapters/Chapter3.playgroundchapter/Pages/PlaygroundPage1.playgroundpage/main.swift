/*:
 By tapping on the thumbnail you can import your artwork from photos in the following view.
 ![editview](editview)
 
 🤔If you don't have your own artwork yet, then you can return to **Chapter 2** to design your facial makeup.
 You can also change the background music.
 
 Click on "Run My Code"😝

 

 */


//#-hidden-code
import UIKit
import BookCore
import PlaygroundSupport
facialMakeup = ._01

//#-end-hidden-code

artwork = /*#-editable-code*/#imageLiteral(resourceName: "01")/*#-end-editable-code*/
music = ./*#-editable-code*/music1/*#-end-editable-code*/

//#-hidden-code
testimage = artwork


PlaygroundPage.current.liveView = instantiateLiveView()
//#-end-hidden-code

