import SwiftUI
import PlaygroundSupport
struct ContentView : View{
    var body: some View{
        //Text("hello")
        Image("arimage")
            .resizable()

        //.foregroundColor(.white)

    }
}

PlaygroundPage.current.setLiveView(ContentView())

