import SwiftUI
import PlaygroundSupport
struct ContentView : View{
    var body: some View{

        Image("arimage")
            .resizable()



    }
}

PlaygroundPage.current.setLiveView(ContentView())

//Music resources
// https://y.qq.com/n/yqq/album/001hhByZ026hHI.html
//https://y.qq.com/n/yqq/album/002murJU23QKoX.html
