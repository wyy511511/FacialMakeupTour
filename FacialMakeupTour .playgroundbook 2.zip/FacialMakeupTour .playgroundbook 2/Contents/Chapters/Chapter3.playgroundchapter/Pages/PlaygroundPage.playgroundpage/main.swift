/*:
 Here are some classic Facial Makeups.
 
 You can pick what you like to experience！😉
 
 You can also change the background music.
 
 You only need to edit the value of the **facialMakeup** and **music**.
 

 
 ![select](select)
 */


//#-hidden-code
import UIKit
import BookCore
import PlaygroundSupport

//#-end-hidden-code

facialMakeup = ./*#-editable-code*/_01/*#-end-editable-code*/
music = ./*#-editable-code*/music1/*#-end-editable-code*/
// Click on "Run My Code" 😝
//#-hidden-code

testimage = #imageLiteral(resourceName: facialMakeup.rawValue)

PlaygroundPage.current.liveView = instantiateLiveView()
//#-end-hidden-code

