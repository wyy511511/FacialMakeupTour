/*:
 # Now, Design Your Facial Makeup! 😉
 
 ## **Tips-1:**
 Use your **Apple Pencil** to draw your own Facial Makeup.
 
 ## **Tips-2:**
 Designing your Facial Makeup according to the template will get a better experience with AR in the next Chapter.
 
 ## **Tips-3:**
 Suggested drawing on the **landscape screen**.
 
 ## **Tips-4:**
 Tap **save** button to save your artwork.
 
 ## **Tips-5:**
 If you can't find palette, please tap "Start Page Over".
 
 # Choose your preferred template！⬇️
 */
//#-hidden-code

import UIKit
import BookCore
import PlaygroundSupport
//#-end-hidden-code
bgImg = ./*#-editable-code*/template1/*#-end-editable-code*/
// Click "Run My Code" to make the changes take effect.

//#-hidden-code

PlaygroundPage.current.liveView = instantiateMainView()
//#-end-hidden-code

/*:
 ![template](template)
 [Next Page](@next)

 */




