//
//  MainViewController.swift
//  BookCore
//
//  Created by Gavin on 2021/3/11.
//
import UIKit
import PlaygroundSupport
import PencilKit
import PhotosUI
public enum BgImg: String {
    case template1 = "template1"
    case template2 = "template2"
    case template3 = "template3"
    case template4 = "template4"
}

public var bgImg: BgImg = .template1

@objc(BookCore_MainViewController)
public class MainViewController: UIViewController,PKCanvasViewDelegate, PKToolPickerObserver, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {


    @IBOutlet var canvasView: PKCanvasView!
    @IBOutlet var bgImgV: UIImageView!
    //camer action
    var toolPicker: PKToolPicker!
    
    let canvasWidth: CGFloat = 500
    let canvasOverscrollHight: CGFloat = 500
    
    var drawing = PKDrawing()
    
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        bgImgV.image = UIImage(named: bgImg.rawValue)
        canvasView.delegate = self
        canvasView.drawing = drawing
        
        canvasView.alwaysBounceVertical = true
    
        if #available(iOS 14.0, *) {

            canvasView.drawingPolicy = .anyInput
        } else {
            // Fallback on earlier versions
        }
        if #available(iOS 14.0, *) {
            toolPicker = PKToolPicker()
            
        } else {
            // Set up the tool picker, using the window of our parent because our view has not
            // been added to a window yet.
            let window = parent?.view.window
            toolPicker = PKToolPicker.shared(for: window!)
        }
        toolPicker.setVisible(true, forFirstResponder: canvasView)
        toolPicker.addObserver(canvasView)
        toolPicker.addObserver(self)
        canvasView.becomeFirstResponder()
        
        
        // Do any additional setup after loading the view.
    }
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let canvasScale = 1
        canvasView.minimumZoomScale = CGFloat(canvasScale)
        canvasView.maximumZoomScale = CGFloat(canvasScale)
        canvasView.zoomScale = CGFloat(canvasScale)
        canvasView.contentOffset = CGPoint(x: 0, y:0)
    }


    public override  var prefersHomeIndicatorAutoHidden: Bool{
        return true
    }
//
    @IBAction func saveDrawingToCamera(_ sender: Any) {
        UIGraphicsBeginImageContextWithOptions( canvasView.bounds.size, false, UIScreen.main.scale)

        canvasView.drawHierarchy(in: canvasView.bounds, afterScreenUpdates: true)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        if image != nil{
            //import PhotosUI
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAsset(from: image!)
            },completionHandler:{success, error in
                //deal with success or error
            })
        }
    }

    func updateContentSizeForDrawing() {

        let drawing = canvasView.drawing
        let contentHeight: CGFloat


        if !drawing.bounds.isNull {
            contentHeight = max(canvasView.bounds.height, (drawing.bounds.maxY + self.canvasOverscrollHight) * canvasView.zoomScale)
        } else {
            contentHeight = canvasView.bounds.height
        } 
        canvasView.contentSize = CGSize(width: canvasWidth * canvasView.zoomScale, height: contentHeight)

    }

    public func receive(_ message: PlaygroundValue) {

    }


}
