//
//  MusicManager.swift
//  PlaygroundBook
//
//  Created by 511 on 2021/4/18.
//
import AVFoundation

public enum Music: String {
    case music1 = "a1"
    case music2 = "a2"

}

public class MusicManager {
    var audioPlayer: AVAudioPlayer!
    
    init() {
        audioPlayer = AVAudioPlayer()
    }
    func play(music: Music) {

        let session = AVAudioSession.sharedInstance()

        do {
            try session.setActive(true)
            try session.setCategory(AVAudioSession.Category.playback)
            let path = Bundle.main.path(forResource: music.rawValue, ofType: "mp3")
            let soundUrl = NSURL(fileURLWithPath: path!)
            try audioPlayer = AVAudioPlayer(contentsOf: soundUrl as URL)
            audioPlayer.prepareToPlay()
            audioPlayer.volume = 1.0
            audioPlayer.numberOfLoops = -1 //-1:infinite
            audioPlayer.play()
        } catch {
            print(error)
        }
        
    }
}
