//
//  TexturedFace.swift
//  PlaygroundBook
//
//  Created by 511 on 2021/3/15.
//

import ARKit
import SceneKit

public var testimage: Any? = #imageLiteral(resourceName: "wireframeTexture")
public var artwork: Any? = #imageLiteral(resourceName: "wireframeTexture")
public var facialMakeup: FacialMakeup = ._01
public enum FacialMakeup: String {
    case _01 = "01"
    case _02 = "02"
    case _03 = "03"
    case _04 = "04"
    case _05 = "05"
    case _06 = "06"
    case _07 = "07"
    case _08 = "08"
}

class TexturedFace: NSObject, VirtualContentController {
    var contentNode: SCNNode?
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        guard let sceneView = renderer as? ARSCNView,
            anchor is ARFaceAnchor else { return nil }

        let faceGeometry = ARSCNFaceGeometry(device: sceneView.device!,fillMesh: true)!

        let material = faceGeometry.firstMaterial!


        material.diffuse.contents = testimage
        material.lightingModel = .physicallyBased

        contentNode = SCNNode(geometry: faceGeometry)

        return contentNode
    }
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let faceGeometry = node.geometry as? ARSCNFaceGeometry,
            let faceAnchor = anchor as? ARFaceAnchor
            else { return }

        faceGeometry.update(from: faceAnchor.geometry)
    }
}
